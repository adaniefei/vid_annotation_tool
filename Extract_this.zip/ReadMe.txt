Please put all folders and files from this zip file to the root directory.

The db_test.xml contains the database information that is used for both tools. To custermize the file for your own video database, please change the following values:
- <Name>db_name</Name> => Your database name
- For each video under <Lectures>...</Lectures>
	<Lecture>
                <Id>video_name</Id>
                <Title>video_name</Title> => title used to name the folder in "export_frames" directory for "image based annotation mode"
                <MetaData>
                    <RawTitle>video_name.mp4</RawTitle>
                </MetaData>
                <Videos>
                    <Main>
                        <Video>
                            <Path>video_name.mp4</Path> => video path used under "video based annotation mode"
                        </Video>                        
                    </Main>                    
                </Videos>     
                <AudioStreams></AudioStreams>
                <Transcriptions>                    
                </Transcriptions>                     
        </Lecture>

The conf_file.conf contains parameters used for both tools. It includes:
- VIDEO_DATABASE_PATH: path of video database file (".xml")
- VIDEO_FILES_PATH: directory contains videos that will be annotated
- OUTPUT_PATH: main directory for saving outputs
- VIDEO_BASED_ANNOTATIONS: flag for switching between video/image ("1" or "0") based annotation
- OUTPUT_FRAME_EXPORT: main directory for exporting frames of each videos
- FRAME_EXPORT_FPS: number of exporting frames per second
- OUTPUT_FRAME_EXPORT_FORMAT: image file format of exporting frames (e.g. jpg, png)
- OUTPUT_FRAME_EXPORT_QUALITY: image file quality of exporting frames ("100" -> highest quality)





	


